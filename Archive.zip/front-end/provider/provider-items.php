<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../../back-end/config/database.php';
require_once '../../back-end/models/BaseModel.php';
require_once '../../back-end/models/Item.php';
require_once '../../back-end/models/Category.php';
require_once '../../back-end/models/Provider.php';
require_once '../../back-end/models/PickupLocation.php';

if (empty($_SESSION['providerId'])) {
    header('Location: ../shared/login.php');
    exit;
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: ../shared/landing.php');
    exit;
}

$providerId = $_SESSION['providerId'];

$itemModel = new Item();
$categoryModel = new Category();
$providerModel = new Provider();
$locationModel = new PickupLocation();

$categoryModel->seed();

$tab = $_GET['tab'] ?? 'all';
$itemFilter = [];

if ($tab === 'sell') {
    $itemFilter['listingType'] = 'sell';
} elseif ($tab === 'donate') {
    $itemFilter['listingType'] = 'donate';
}

$items = $itemModel->getByProvider($providerId, $itemFilter);
usort($items, function ($a, $b) {
    return strcmp((string)($b['_id'] ?? ''), (string)($a['_id'] ?? ''));
});

$categories = $categoryModel->getAll();
$provider = $providerModel->findById($providerId);
$locations = $locationModel->getByProvider($providerId);

$defaultLocation = null;
foreach ($locations as $loc) {
    if (!empty($loc['isMain']) || !empty($loc['isDefault'])) {
        $defaultLocation = $loc;
        break;
    }
}
if (!$defaultLocation && !empty($locations)) {
    $defaultLocation = $locations[0];
}

$providerName = $provider['businessName'] ?? 'Provider';
$providerEmail = $provider['email'] ?? '';
$providerLogo = $provider['businessLogo'] ?? '';
$firstName = explode(' ', trim($providerName))[0] ?: 'Provider';
$today = date('Y-m-d');
$formError = '';

/* ---------- QUICK UPDATE AJAX ---------- */
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    str_contains($_SERVER['CONTENT_TYPE'] ?? '', 'application/json')
) {
    header('Content-Type: application/json');

    try {
        $input = json_decode(file_get_contents('php://input'), true);
        $itemId = trim($input['id'] ?? '');

        if ($itemId === '') {
            throw new Exception('Missing item ID');
        }

        $fields = [
            'updatedAt' => new MongoDB\BSON\UTCDateTime()
        ];

        if (($input['quantity'] ?? '') !== '') {
            $fields['quantity'] = (int)$input['quantity'];
            $fields['isAvailable'] = ((int)$input['quantity'] > 0);
        }

        $listingType = trim($input['listingType'] ?? '');
        if ($listingType === 'donate') {
            $fields['listingType'] = 'donate';
            $fields['price'] = 0;
        } elseif ($listingType === 'sell') {
            $fields['listingType'] = 'sell';
            $fields['price'] = (float)($input['price'] ?? 0);
        }

        if (!empty($input['expiryDate'])) {
            $fields['expiryDate'] = new MongoDB\BSON\UTCDateTime(strtotime($input['expiryDate']) * 1000);
        }

        if (!empty($input['pickupDate'])) {
            $fields['pickupDate'] = new MongoDB\BSON\UTCDateTime(strtotime($input['pickupDate']) * 1000);
        }

        if (!empty($input['pickupLocationId'])) {
            $fields['pickupLocationId'] = new MongoDB\BSON\ObjectId($input['pickupLocationId']);
        }

        $itemModel->updateById($itemId, $fields);

        echo json_encode([
            'success' => true
        ]);
    } catch (Throwable $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
    exit;
}

/* ---------- FORM POSTS ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formAction = $_POST['formAction'] ?? 'addItem';

    if ($formAction === 'deleteItem') {
        header('Content-Type: application/json');

        try {
            $itemId = trim($_POST['itemId'] ?? '');
            if ($itemId === '') {
                throw new Exception('Missing item id');
            }

            $itemModel->deleteById($itemId);

            echo json_encode([
                'success' => true
            ]);
        } catch (Throwable $e) {
            echo json_encode([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
        exit;
    }

    $photoUrl = trim($_POST['existingPhotoUrl'] ?? '');

    try {
        if (!empty($_FILES['itemPhoto']['name']) && (int)($_FILES['itemPhoto']['error'] ?? 1) === 0) {
            $uploadDir = '../../uploads/items/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $originalName = basename($_FILES['itemPhoto']['name']);
            $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

            if (!in_array($extension, $allowed, true)) {
                throw new Exception('Invalid image type. Please upload jpg, jpeg, png, gif, or webp.');
            }

            $newFileName = uniqid('item_', true) . '.' . $extension;
            $targetPath = $uploadDir . $newFileName;

            if (!move_uploaded_file($_FILES['itemPhoto']['tmp_name'], $targetPath)) {
                throw new Exception('Failed to upload image.');
            }

            $photoUrl = '../../uploads/items/' . $newFileName;
        }

        if ($formAction === 'editItem') {
            $editItemId = trim($_POST['editItemId'] ?? '');
            if ($editItemId === '') {
                throw new Exception('Missing edit item id');
            }

            $data = [
                'categoryId'       => $_POST['categoryId'] ?? '',
                'pickupLocationId' => $_POST['pickupLocationId'] ?? '',
                'itemName'         => trim($_POST['itemName'] ?? ''),
                'description'      => trim($_POST['itemDetails'] ?? ''),
                'photoUrl'         => $photoUrl,
                'listingType'      => $_POST['itemType'] ?? 'donate',
                'price'            => (($_POST['itemType'] ?? '') === 'sell') ? (float)($_POST['price'] ?? 0) : 0,
                'pickupDate'       => $_POST['pickupDate'] ?? '',
                'quantity'         => (int)($_POST['quantity'] ?? 0),
            ];

            $itemModel->updateById($editItemId, $data);
        } else {
            $data = [
                'categoryId'       => $_POST['categoryId'] ?? '',
                'pickupLocationId' => $_POST['pickupLocationId'] ?? '',
                'itemName'         => trim($_POST['itemName'] ?? ''),
                'description'      => trim($_POST['itemDetails'] ?? ''),
                'photoUrl'         => $photoUrl,
                'listingType'      => $_POST['itemType'] ?? 'donate',
                'price'            => (($_POST['itemType'] ?? '') === 'sell') ? (float)($_POST['price'] ?? 0) : 0,
                'pickupDate'       => $_POST['pickupDate'] ?? '',
                'quantity'         => (int)($_POST['quantity'] ?? 0),
                'pickupTimes'      => [],
            ];

            $itemModel->create($providerId, $data);
        }

        header('Location: provider-items.php?tab=' . urlencode($_POST['itemType'] ?? 'all'));
        exit;
    } catch (Exception $e) {
        $formError = $e->getMessage();
    }
}

/* ---------- SEARCH DATA ---------- */
$allItemsForSearch = $itemModel->getByProvider($providerId);
$searchItems = [];

foreach ($allItemsForSearch as $item) {
    $searchItems[] = [
        'id' => (string)($item['_id'] ?? ''),
        'name' => $item['itemName'] ?? '',
        'photoUrl' => $item['photoUrl'] ?? '',
        'listingType' => strtolower($item['listingType'] ?? ''),
        'price' => $item['price'] ?? 0
    ];
}

function formatDateForInput($value): string {
    if (empty($value)) return '';
    if ($value instanceof MongoDB\BSON\UTCDateTime) {
        return $value->toDateTime()->format('Y-m-d');
    }
    if (is_string($value)) {
        $ts = strtotime($value);
        return $ts ? date('Y-m-d', $ts) : '';
    }
    return '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>RePlate – My Items</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    body{
      font-family:'Playfair Display', serif;
      background:#f4f7fc;
      color:#183482;
      min-height:100vh;
    }

    nav.navbar{
      display:flex;
      align-items:center;
      justify-content:space-between;
      padding:0 22px;
      height:72px;
      background:linear-gradient(90deg,#1a3a6b 0%,#2255a4 60%,#3a7bd5 100%);
      position:sticky;
      top:0;
      z-index:2000;
      box-shadow:0 2px 16px rgba(26,58,107,.18);
    }

    .nav-left,.nav-right,.nav-provider-info{
      display:flex;
      align-items:center;
      gap:14px;
    }

    .nav-logo{height:90px}

    .nav-search-wrap{
      position:relative;
      width:280px;
    }

    .nav-search-wrap svg{
      position:absolute;
      left:14px;
      top:50%;
      transform:translateY(-50%);
      opacity:.65;
      pointer-events:none;
      color:#fff;
    }

    .nav-search-wrap input{
      width:100%;
      height:40px;
      border-radius:999px;
      border:1.5px solid rgba(255,255,255,.35);
      background:rgba(255,255,255,.12);
      color:#fff;
      padding:0 16px 0 40px;
      outline:none;
      font-size:14px;
    }

    .nav-search-wrap input::placeholder{color:rgba(255,255,255,.7)}

    .nav-provider-logo{
      width:46px;
      height:46px;
      border-radius:50%;
      border:2px solid rgba(255,255,255,.55);
      background:rgba(255,255,255,.15);
      display:flex;
      align-items:center;
      justify-content:center;
      overflow:hidden;
      color:#fff;
      font-weight:700;
      flex-shrink:0;
    }

    .nav-provider-logo img{width:100%;height:100%;object-fit:cover}
    .nav-provider-name{font-size:15px;font-weight:700;color:#fff}
    .nav-provider-email{font-size:12px;color:rgba(255,255,255,.78)}

    .page-body{
      display:flex;
      min-height:calc(100vh - 72px);
    }

    .sidebar{
      width:240px;
      background:linear-gradient(180deg,#1a3a6b 0%,#2255a4 60%,#3a7bd5 100%);
      padding:34px 24px 28px;
      color:#fff;
      flex-shrink:0;
      display:flex;
      flex-direction:column;
    }

    .sidebar-welcome{color:rgba(255,255,255,.82);font-size:17px;margin-bottom:4px}
    .sidebar-name{color:rgba(255,255,255,.62);font-size:38px;font-weight:700;line-height:1.1;margin-bottom:34px}

    .sidebar-nav{
      display:flex;
      flex-direction:column;
      gap:16px;
      flex:1;
    }

    .sidebar-link{
      display:flex;
      align-items:center;
      gap:10px;
      color:rgba(255,255,255,.82);
      text-decoration:none;
      font-size:16px;
      padding:10px 8px;
    }

    .sidebar-link.active{
      color:#fff;
      font-weight:700;
      border-bottom:2px solid rgba(255,255,255,.55);
      padding-bottom:6px;
    }

    .sidebar-logout{
      margin-top:22px;
      background:#fff;
      color:#1a3a6b;
      border:none;
      border-radius:999px;
      padding:12px 0;
      font-size:15px;
      font-weight:700;
      cursor:pointer;
      width:100%;
    }

    .main{
      flex:1;
      padding:34px 28px 40px;
      min-width:0;
    }

    .items-page-wrap{
      max-width:1000px;
      margin:0 auto;
    }

    .page-header h1{
      font-size:42px;
      font-weight:700;
      background:linear-gradient(90deg,#143496 0%,#66a1d9 100%);
      -webkit-background-clip:text;
      -webkit-text-fill-color:transparent;
      background-clip:text;
      margin-bottom:22px;
    }

    .items-header-bar{
      display:grid;
      grid-template-columns:1fr 1fr 1fr;
      gap:14px;
      margin-bottom:22px;
    }

    .mode-btn,.add-item-open-btn{
      min-height:48px;
      border-radius:999px;
      font-size:17px;
      font-weight:700;
      font-family:inherit;
      cursor:pointer;
    }

    .mode-btn{
      border:1.8px solid #e07a1a;
      background:#fff;
      color:#e07a1a;
    }

    .mode-btn.active,
    .add-item-open-btn{
      background:#f6811f;
      color:#fff;
      border:none;
    }

    .helper-card{
      max-width:760px;
      margin:0 auto 22px;
      padding:18px 22px;
      background:#f7fbff;
      border:1.5px solid #d7e1ee;
      border-radius:18px;
      text-align:center;
    }

    .helper-card h3{font-size:21px;margin-bottom:8px}
    .helper-card p{font-size:14px;color:#6f86a8;line-height:1.7}

    .tabs{
      display:grid;
      grid-template-columns:repeat(3,1fr);
      gap:12px;
      margin-bottom:16px;
    }

    .seg-btn{
      text-align:center;
      text-decoration:none;
      min-height:44px;
      display:flex;
      align-items:center;
      justify-content:center;
      border-radius:18px;
      border:1.8px solid #ea8b2c;
      background:#fff;
      color:#183482;
      font-weight:700;
    }

    .seg-btn.active{
      background:#f6811f;
      color:#fff;
      border-color:#f6811f;
    }

    .items-list{display:flex;flex-direction:column;gap:14px}

    .order-row{
      background:#f5f8fc;
      border:1.6px solid #d2dce8;
      border-radius:22px;
      padding:16px 18px;
      display:flex;
      justify-content:space-between;
      gap:18px;
      transition:.2s;
      position:relative;
    }

    .order-row:hover{box-shadow:0 4px 18px rgba(26,58,107,.1)}
    .quick-item-card{cursor:pointer}
    .quick-item-card.selected{
      border:2px solid #ea8b2c !important;
      box-shadow:0 8px 22px rgba(234,139,44,.18);
      background:#fffaf4;
    }

    .order-left{
      display:flex;
      align-items:flex-start;
      gap:16px;
      min-width:0;
      flex:1;
    }

    .logo-box{
      width:98px;
      height:98px;
      border-radius:18px;
      border:1.4px solid #d2dce8;
      background:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      padding:6px;
      overflow:hidden;
      flex-shrink:0;
    }

    .logo-box img{
      width:100%;
      height:100%;
      object-fit:cover;
      border-radius:14px;
    }

    .order-info{
      min-width:0;
      flex:1;
    }

    .order-info h3{
      font-size:22px;
      color:#183482;
      font-weight:700;
      margin-bottom:6px;
    }

    .desc{
      color:#5d79a6;
      font-size:14px;
      line-height:1.6;
      margin-bottom:8px;
      word-break:break-word;
    }

    .info-line{
      color:#4166ad;
      font-size:14px;
      margin:4px 0;
    }

    .order-right{
      display:flex;
      flex-direction:column;
      align-items:flex-end;
      justify-content:space-between;
      gap:12px;
      flex-shrink:0;
    }

    .order-total{
      color:#ea8b2c;
      font-size:26px;
      font-weight:700;
    }

    .item-card-actions{
      display:flex;
      align-items:center;
      gap:10px;
      position:relative;
      z-index:20;
    }

    .icon-action-btn{
      width:38px;
      height:38px;
      border-radius:50%;
      border:1.5px solid #d7e1ee;
      background:#fff;
      color:#183482;
      font-size:16px;
      cursor:pointer;
      display:flex;
      align-items:center;
      justify-content:center;
      position:relative;
      z-index:21;
    }

    .delete-icon-btn{
      color:#c2410c;
      border-color:#f3b39a;
    }

    .quick-update-panel{
      max-width:900px;
      margin:24px auto 0;
      background:#fff7ef;
      border:1.5px solid #f3c999;
      border-radius:22px;
      padding:24px;
      box-shadow:0 8px 24px rgba(234,139,44,.1);
      display:none;
    }

    .quick-update-grid{
      display:grid;
      grid-template-columns:1fr 1fr;
      gap:16px;
    }

    .quick-update-actions{
      display:flex;
      justify-content:flex-end;
      gap:12px;
      margin-top:20px;
    }

    .quick-save-btn,.quick-cancel-btn{
      min-height:44px;
      padding:0 18px;
      border-radius:999px;
      font-family:inherit;
      font-weight:700;
      cursor:pointer;
    }

    .quick-save-btn{
      background:#ea8b2c;
      color:#fff;
      border:none;
    }

    .quick-cancel-btn{
      background:#fff;
      color:#8a9ab5;
      border:2px solid #c8d8ee;
    }

    .form-group{display:flex;flex-direction:column}
    .form-group label{margin-bottom:6px;font-size:14px;font-weight:700;color:#183482}

    .form-input,.form-select,.form-textarea{
      width:100%;
      border:1.5px solid #cfdbea;
      border-radius:14px;
      padding:12px 14px;
      font-size:14px;
      font-family:inherit;
      color:#183482;
      background:#fff;
      outline:none;
    }

    .form-input,.form-select{height:46px}
    .form-textarea{min-height:100px;resize:vertical}

    .search-dropdown{
      display:none;
      position:absolute;
      top:calc(100% + 10px);
      left:0;
      width:100%;
      background:#fff;
      border-radius:18px;
      border:1.5px solid #e0eaf5;
      box-shadow:0 12px 40px rgba(26,58,107,.18);
      z-index:3000;
      overflow:hidden;
    }

    .search-dropdown.visible{display:block}

    .sd-row{
      display:flex;
      align-items:center;
      gap:12px;
      padding:13px 14px;
      text-decoration:none;
      color:inherit;
      transition:.15s;
    }

    .sd-row:hover{background:#f4f8ff}
    .sd-icon{
      width:42px;height:42px;border-radius:12px;background:#edf3fb;
      display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0
    }
    .sd-icon img{width:100%;height:100%;object-fit:cover}
    .sd-name{font-size:14px;font-weight:700;color:#1a3a6b}
    .sd-meta{display:flex;gap:8px;align-items:center;margin-top:4px;flex-wrap:wrap}
    .sd-price{font-size:12px;font-weight:700;color:#ea8b2c}
    .sd-badge{font-size:11px;font-weight:700;padding:4px 8px;border-radius:999px}
    .sd-badge-donate{background:#e8f7ee;color:#2f9b6b}
    .sd-badge-sell{background:#fff4e8;color:#d87917}
    .sd-section-title{font-size:12px;padding:10px 12px 6px;color:#7a8fa8;font-weight:700}

    #addItemModal,#deleteModal{
      display:none;
      position:fixed;
      inset:0;
      background:rgba(12,22,45,.45);
      z-index:4000;
      justify-content:center;
      align-items:center;
      padding:20px;
    }

    #addItemModal > div{
      background:#f7fbff;
      border-radius:26px;
      border:1.5px solid #cfdbea;
      padding:28px;
      max-width:900px;
      width:92%;
      max-height:90vh;
      overflow-y:auto;
      position:relative;
    }

    .delete-modal-card{
      width:min(420px,92%);
      background:#fff;
      border:1.5px solid #d7e1ee;
      border-radius:24px;
      padding:26px 24px;
      text-align:center;
    }

    .delete-modal-actions{
      display:flex;
      justify-content:center;
      gap:12px;
      margin-top:18px;
    }

    .delete-cancel-btn,.delete-confirm-btn{
      min-height:42px;
      padding:0 18px;
      border-radius:999px;
      font-family:inherit;
      font-weight:700;
      cursor:pointer;
    }

    .delete-cancel-btn{
      background:#fff;
      color:#8a9ab5;
      border:2px solid #c8d8ee;
    }

    .delete-confirm-btn{
      background:#d64545;
      color:#fff;
      border:none;
    }

    .close-modal-btn{
      position:absolute;
      top:16px;
      right:20px;
      background:none;
      border:none;
      color:#8aa3c0;
      font-size:32px;
      font-weight:700;
      cursor:pointer;
    }

    .submit-row{
      display:flex;
      justify-content:center;
      margin-top:10px;
    }

    .add-btn{
      min-width:200px;
      height:52px;
      border:none;
      background:#f6811f;
      color:#fff;
      border-radius:999px;
      font-size:18px;
      font-weight:700;
      cursor:pointer;
      font-family:inherit;
    }

    #quickToast{
      display:none;
      position:fixed;
      bottom:24px;
      right:24px;
      background:#183482;
      color:#fff;
      padding:12px 18px;
      border-radius:12px;
      box-shadow:0 10px 24px rgba(0,0,0,.16);
      z-index:5000;
      font-size:14px;
    }

    .hamburger,.mobile-menu{display:none}

    .error-banner{
      background:#fff1f0;
      color:#b42318;
      border:1px solid #f1b5ae;
      padding:12px 14px;
      border-radius:14px;
      margin-bottom:16px;
      font-size:14px;
    }

    .empty-box{
      text-align:center;
      padding:32px 12px;
      color:#6d7da0;
      font-size:22px;
      background:#fff;
      border-radius:20px;
      border:1.5px solid #d7e1ee;
    }

    @media (max-width: 992px){
      .sidebar{display:none}
      .main{padding:24px 16px}
      .nav-search-wrap{display:none}
      .hamburger{
        display:flex;
        flex-direction:column;
        justify-content:center;
        gap:5px;
        width:42px;
        height:42px;
        background:none;
        border:none;
        cursor:pointer;
      }
      .hamburger span{
        width:24px;
        height:2.5px;
        background:#fff;
        border-radius:2px;
        margin:0 auto;
        transition:.3s;
      }
      .hamburger.open span:nth-child(1){transform:translateY(7px) rotate(45deg)}
      .hamburger.open span:nth-child(2){opacity:0}
      .hamburger.open span:nth-child(3){transform:translateY(-8px) rotate(-45deg)}

      .mobile-menu{
        position:fixed;
        top:72px;
        left:0;
        width:100%;
        height:calc(100vh - 72px);
        background:linear-gradient(180deg,#1a3a6b 0%,#2255a4 60%,#3a7bd5 100%);
        z-index:2500;
        padding:24px 20px;
      }
      .mobile-menu.open{display:block}
      .mobile-menu a{
        display:block;
        color:#fff;
        text-decoration:none;
        font-size:18px;
        font-weight:700;
        padding:16px 0;
        border-bottom:1px solid rgba(255,255,255,.12);
      }
      .mobile-search{
        position:relative;
        margin-bottom:18px;
      }
      .mobile-search svg{
        position:absolute;
        left:14px;
        top:50%;
        transform:translateY(-50%);
        color:#fff;
        opacity:.7;
      }
      .mobile-search input{
        width:100%;
        height:44px;
        border-radius:999px;
        border:1.5px solid rgba(255,255,255,.35);
        background:rgba(255,255,255,.12);
        color:#fff;
        padding:0 16px 0 40px;
        outline:none;
      }
      .mobile-search .search-dropdown{
        width:100%;
      }
      .items-header-bar,
      .tabs,
      .quick-update-grid{
        grid-template-columns:1fr;
      }
      .order-row{
        flex-direction:column;
        align-items:flex-start;
      }
      .order-right{
        width:100%;
        align-items:flex-start;
      }
      .nav-provider-text{display:none}
    }
  </style>
</head>
<body>
<nav class="navbar">
  <div class="nav-left">
    <img class="nav-logo" src="../../images/Replate-white.png" alt="RePlate">
  </div>

  <div class="nav-right">
    <div class="nav-search-wrap" id="searchWrap">
      <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <circle cx="11" cy="11" r="8"></circle>
        <path d="M21 21l-4.35-4.35"></path>
      </svg>
      <input type="text" id="searchInput" placeholder="Search items..." autocomplete="off">
      <div class="search-dropdown" id="searchDropdown"></div>
    </div>

    <div class="nav-provider-info">
      <div class="nav-provider-logo">
        <?php if ($providerLogo): ?>
          <img src="<?= htmlspecialchars($providerLogo) ?>" alt="<?= htmlspecialchars($providerName) ?>">
        <?php else: ?>
          <?= htmlspecialchars(strtoupper(mb_substr($providerName, 0, 1))) ?>
        <?php endif; ?>
      </div>
      <div class="nav-provider-text">
        <div class="nav-provider-name"><?= htmlspecialchars($providerName) ?></div>
        <div class="nav-provider-email"><?= htmlspecialchars($providerEmail) ?></div>
      </div>
    </div>

    <button id="hamburger" class="hamburger" type="button" onclick="toggleMobileMenu()">
      <span></span>
      <span></span>
      <span></span>
    </button>
  </div>
</nav>

<div id="mobileMenu" class="mobile-menu">
  <div class="mobile-search">
    <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
      <circle cx="11" cy="11" r="8"></circle>
      <path d="M21 21l-4.35-4.35"></path>
    </svg>
    <input type="text" id="mobileSearchInput" placeholder="Search items..." autocomplete="off">
    <div class="search-dropdown" id="mobileSearchDropdown"></div>
  </div>

  <a href="provider-dashboard.php">Dashboard</a>
  <a href="provider-items.php">Items</a>
  <a href="provider-orders.php">Orders</a>
  <a href="provider-profile.php">Profile</a>
  <a href="provider-dashboard.php?logout=1">Logout</a>
</div>

<div class="page-body">
  <aside class="sidebar">
    <p class="sidebar-welcome">Welcome Back,</p>
    <p class="sidebar-name"><?= htmlspecialchars($firstName) ?></p>

    <nav class="sidebar-nav">
      <a href="provider-dashboard.php" class="sidebar-link">Dashboard</a>
      <a href="provider-items.php" class="sidebar-link active">Items</a>
      <a href="provider-orders.php" class="sidebar-link">Orders</a>
      <a href="provider-profile.php" class="sidebar-link">Profile</a>
    </nav>

    <button class="sidebar-logout" onclick="window.location.href='provider-dashboard.php?logout=1'">Logout</button>
  </aside>

  <main class="main">
    <div class="items-page-wrap">
      <?php if ($formError !== ''): ?>
        <div class="error-banner"><?= htmlspecialchars($formError) ?></div>
      <?php endif; ?>

      <div class="page-header">
        <h1>My Items</h1>
      </div>

      <div class="items-header-bar">
        <button type="button" class="mode-btn active" id="viewItemsBtn" onclick="showMode('view')">View Items</button>
        <button type="button" class="mode-btn" id="quickUpdateBtn" onclick="showQuickHelper()">Quick Update</button>
        <button type="button" class="add-item-open-btn" onclick="resetAddItemModal(); document.getElementById('addItemModal').style.display='flex'">+ Add New Item</button>
      </div>

      <div class="helper-card" id="viewItemsHelper">
        <h3>View Your Items</h3>
        <p>See all your available items here. You can select any item to update its daily availability, and edit or delete it from the action buttons.</p>
      </div>

      <div class="helper-card" id="quickUpdateHelper" style="display:none;">
        <h3>Daily Availability Update</h3>
        <p>Select an item card, then update quantity, type, price, expiry date, pickup date, and branch.</p>
      </div>

      <div class="tabs">
        <a class="seg-btn <?= $tab === 'all' ? 'active' : '' ?>" href="provider-items.php?tab=all">All</a>
        <a class="seg-btn <?= $tab === 'donate' ? 'active' : '' ?>" href="provider-items.php?tab=donate">Donate</a>
        <a class="seg-btn <?= $tab === 'sell' ? 'active' : '' ?>" href="provider-items.php?tab=sell">Sell</a>
      </div>

      <div class="items-list">
        <?php if (empty($items)): ?>
          <div class="empty-box">No <?= htmlspecialchars($tab) ?> items yet.</div>
        <?php else: ?>
          <?php foreach ($items as $item): ?>
            <?php
              $itemId = (string)($item['_id'] ?? '');
              $itemName = $item['itemName'] ?? 'Unnamed item';
              $itemDesc = $item['description'] ?? '';
              $itemPhoto = $item['photoUrl'] ?? '';
              $listingType = strtolower($item['listingType'] ?? 'donate');
              $price = (float)($item['price'] ?? 0);
              $quantity = (int)($item['quantity'] ?? 0);
              $pickupLocationId = isset($item['pickupLocationId']) ? (string)$item['pickupLocationId'] : '';
              $pickupDate = formatDateForInput($item['pickupDate'] ?? '');
              $expiryDate = formatDateForInput($item['expiryDate'] ?? '');

              $categoryName = 'Unknown category';
              if (!empty($item['categoryId'])) {
                  $cat = $categoryModel->findById((string)$item['categoryId']);
                  if ($cat && !empty($cat['name'])) {
                      $categoryName = $cat['name'];
                  }
              }

              $displayPrice = $listingType === 'donate' ? 'Donation' : ('SAR ' . number_format($price, 2));
            ?>
            <div class="order-row quick-item-card"
     data-id="<?= htmlspecialchars($itemId) ?>"
     data-quantity="<?= htmlspecialchars((string)$quantity) ?>"
     data-type="<?= htmlspecialchars($listingType) ?>"
     data-price="<?= htmlspecialchars((string)$price) ?>"
     data-expiry="<?= htmlspecialchars($expiryDate) ?>"
     data-pickupdate="<?= htmlspecialchars($pickupDate) ?>"
     data-pickuplocation="<?= htmlspecialchars($pickupLocationId) ?>"
     onclick="selectQuickItem(this)">
              <div class="order-left">
                <div class="logo-box">
                  <?php if ($itemPhoto): ?>
                    <img src="<?= htmlspecialchars($itemPhoto) ?>" alt="<?= htmlspecialchars($itemName) ?>">
                  <?php else: ?>
                    <span>🍱</span>
                  <?php endif; ?>
                </div>

                <div class="order-info">
                  <h3><?= htmlspecialchars($itemName) ?></h3>
                  <div class="desc"><?= htmlspecialchars($itemDesc) ?></div>
                  <div class="info-line">Category: <?= htmlspecialchars($categoryName) ?></div>
                  <div class="info-line">Quantity: <?= htmlspecialchars((string)$quantity) ?></div>
                  <div class="info-line">Type: <?= htmlspecialchars(ucfirst($listingType)) ?></div>
                </div>
              </div>

              <div class="order-right">
                <div class="order-total"><?= htmlspecialchars($displayPrice) ?></div>

                <div class="item-card-actions">
                  <button
  type="button"
  class="icon-action-btn"
  data-id="<?= htmlspecialchars($itemId) ?>"
  data-name="<?= htmlspecialchars($itemName) ?>"
  data-description="<?= htmlspecialchars($itemDesc) ?>"
  data-categoryid="<?= htmlspecialchars((string)($item['categoryId'] ?? '')) ?>"
  data-price="<?= htmlspecialchars((string)$price) ?>"
  data-pickuplocation="<?= htmlspecialchars($pickupLocationId) ?>"
  data-pickupdate="<?= htmlspecialchars($pickupDate) ?>"
  data-photo="<?= htmlspecialchars($itemPhoto) ?>"
  data-type="<?= htmlspecialchars($listingType) ?>"
  onclick="event.stopPropagation(); openEditItemModal(this, event); return false;"
>✏️</button>
<button
  type="button"
  class="icon-action-btn delete-icon-btn"
  onclick="event.stopPropagation(); deleteItem('<?= htmlspecialchars($itemId) ?>', event); return false;"
>🗑</button>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>

      <div id="quickUpdatePanel" class="quick-update-panel">
        <div class="quick-update-grid">
          <div class="form-group">
            <label for="quickQuantity">Quantity</label>
            <input type="number" id="quickQuantity" class="form-input" min="0">
          </div>

          <div class="form-group">
            <label for="quickType">Type</label>
            <select id="quickType" class="form-select" onchange="handleQuickTypeChange()">
              <option value="donate">Donate</option>
              <option value="sell">Sell</option>
            </select>
          </div>

          <div class="form-group">
            <label for="quickPrice">Price</label>
            <input type="number" id="quickPrice" class="form-input" min="0" step="0.01">
          </div>

          <div class="form-group">
            <label for="quickExpiryDate">Expiry Date</label>
            <input type="date" id="quickExpiryDate" class="form-input">
          </div>

          <div class="form-group">
            <label for="quickPickupDate">Pickup Date</label>
            <input type="date" id="quickPickupDate" class="form-input">
          </div>

          <div class="form-group">
            <label for="quickPickupLocation">Pickup Location</label>
            <select id="quickPickupLocation" class="form-select">
              <option value="">Select location</option>
              <?php foreach ($locations as $loc): ?>
                <option value="<?= htmlspecialchars((string)$loc['_id']) ?>">
                  <?= htmlspecialchars($loc['locationName'] ?? (($loc['street'] ?? '') . ' ' . ($loc['city'] ?? ''))) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <input type="hidden" id="quickItemId">

        <div class="quick-update-actions">
          <button type="button" class="quick-cancel-btn" onclick="clearQuickSelection()">Cancel</button>
          <button type="button" class="quick-save-btn" onclick="saveQuickUpdate()">Save Update</button>
        </div>
      </div>
    </div>
  </main>
</div>

<div id="addItemModal">
  <div>
    <button type="button" class="close-modal-btn" onclick="document.getElementById('addItemModal').style.display='none'">&times;</button>
    <h1>Add Item</h1>

    <form id="addItemForm" method="POST" enctype="multipart/form-data">
      <input type="hidden" name="formAction" id="formAction" value="addItem">
      <input type="hidden" name="editItemId" id="editItemId" value="">
      <input type="hidden" name="existingPhotoUrl" id="existingPhotoUrl" value="">

      <div class="form-group" style="margin-bottom:16px;display:none;" id="currentImageWrap">
        <label>Current Image</label>
        <img id="currentImagePreview" src="" alt="" style="width:100px;height:100px;object-fit:cover;border-radius:14px;border:1px solid #d7e1ee;">
      </div>

      <div class="quick-update-grid">
        <div class="form-group">
          <label for="itemName">Item Name</label>
          <input type="text" name="itemName" id="itemName" class="form-input" required>
        </div>

        <div class="form-group">
          <label for="categoryId">Category</label>
          <select name="categoryId" id="categoryId" class="form-select" required>
            <option value="">Select category</option>
            <?php foreach ($categories as $cat): ?>
              <option value="<?= htmlspecialchars((string)$cat['_id']) ?>">
                <?= htmlspecialchars($cat['name'] ?? 'Category') ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group">
          <label for="pickupLocationId">Pickup Location</label>
          <select name="pickupLocationId" id="pickupLocationId" class="form-select" required>
            <option value="">Select location</option>
            <?php foreach ($locations as $loc): ?>
              <option value="<?= htmlspecialchars((string)$loc['_id']) ?>">
                <?= htmlspecialchars($loc['locationName'] ?? (($loc['street'] ?? '') . ' ' . ($loc['city'] ?? ''))) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group">
          <label for="pickupDate">Pickup Date</label>
          <input type="date" name="pickupDate" id="pickupDate" class="form-input" value="<?= htmlspecialchars($today) ?>">
        </div>

        <div class="form-group">
          <label for="quantity">Quantity</label>
          <input type="number" name="quantity" id="quantity" class="form-input" min="0" value="1">
        </div>

        <div class="form-group">
          <label for="priceInput">Price</label>
          <input type="number" name="price" id="priceInput" class="form-input" min="0" step="0.01" value="0">
        </div>

        <div class="form-group" style="grid-column:1 / -1;">
          <label for="itemDetails">Description</label>
          <textarea name="itemDetails" id="itemDetails" class="form-textarea" required></textarea>
        </div>

        <div class="form-group" style="grid-column:1 / -1;">
          <label for="itemPhoto">Item Photo</label>
          <input type="file" name="itemPhoto" id="itemPhoto" class="form-input" accept=".jpg,.jpeg,.png,.gif,.webp">
        </div>

        <div class="form-group" style="grid-column:1 / -1;">
          <label>Item Type</label>
          <div style="display:flex;gap:18px;align-items:center;flex-wrap:wrap;padding-top:10px;">
            <label style="display:flex;align-items:center;gap:8px;font-weight:400;">
              <input type="radio" name="itemType" value="donate" checked onclick="document.getElementById('priceInput').value=0; document.getElementById('priceInput').disabled=true;">
              Donate
            </label>
            <label style="display:flex;align-items:center;gap:8px;font-weight:400;">
              <input type="radio" name="itemType" value="sell" onclick="document.getElementById('priceInput').disabled=false;">
              Sell
            </label>
          </div>
        </div>
      </div>

      <div class="submit-row">
        <button type="submit" class="add-btn">Add Item</button>
      </div>
    </form>
  </div>
</div>

<div id="deleteModal">
  <div class="delete-modal-card">
    <h3>Delete Item</h3>
    <p>Are you sure you want to delete this item?</p>
    <div class="delete-modal-actions">
      <button type="button" class="delete-cancel-btn" onclick="closeDeleteModal()">Cancel</button>
      <button type="button" class="delete-confirm-btn" onclick="confirmDeleteItem()">Delete</button>
    </div>
  </div>
</div>

<div id="quickToast"></div>

<script>
const itemSearchData = <?= json_encode($searchItems, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
let deleteTargetItemId = '';
let searchTimer = null;

function esc(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function toggleMobileMenu() {
  const menu = document.getElementById('mobileMenu');
  const btn = document.getElementById('hamburger');
  if (!menu || !btn) return;
  menu.classList.toggle('open');
  btn.classList.toggle('open');
  document.body.style.overflow = menu.classList.contains('open') ? 'hidden' : '';
}

function closeMobileMenu() {
  const menu = document.getElementById('mobileMenu');
  const btn = document.getElementById('hamburger');
  if (menu) menu.classList.remove('open');
  if (btn) btn.classList.remove('open');
  document.body.style.overflow = '';
}

function showQuickToast(message) {
  const toast = document.getElementById('quickToast');
  if (!toast) return;
  toast.textContent = message;
  toast.style.display = 'block';
  setTimeout(() => {
    toast.style.display = 'none';
  }, 2200);
}

function showMode() {
  const viewItemsHelper = document.getElementById('viewItemsHelper');
  const quickUpdateHelper = document.getElementById('quickUpdateHelper');
  const viewItemsBtn = document.getElementById('viewItemsBtn');
  const quickUpdateBtn = document.getElementById('quickUpdateBtn');

  if (viewItemsHelper) viewItemsHelper.style.display = 'block';
  if (quickUpdateHelper) quickUpdateHelper.style.display = 'none';
  if (viewItemsBtn) viewItemsBtn.classList.add('active');
  if (quickUpdateBtn) quickUpdateBtn.classList.remove('active');

  clearQuickSelection();
}

function showQuickHelper() {
  const viewItemsHelper = document.getElementById('viewItemsHelper');
  const quickUpdateHelper = document.getElementById('quickUpdateHelper');
  const viewItemsBtn = document.getElementById('viewItemsBtn');
  const quickUpdateBtn = document.getElementById('quickUpdateBtn');

  if (viewItemsHelper) viewItemsHelper.style.display = 'none';
  if (quickUpdateHelper) quickUpdateHelper.style.display = 'block';
  if (viewItemsBtn) viewItemsBtn.classList.remove('active');
  if (quickUpdateBtn) quickUpdateBtn.classList.add('active');
}

function clearQuickSelection() {
  document.querySelectorAll('.quick-item-card').forEach(el => el.classList.remove('selected'));
  const panel = document.getElementById('quickUpdatePanel');
  if (panel) panel.style.display = 'none';
  document.getElementById('quickItemId').value = '';
}

<script>
function selectQuickItem(card) {
  if (!card) return;

  const itemId = card.getAttribute('data-id') || '';
  const quantity = card.getAttribute('data-quantity') || '';
  const type = card.getAttribute('data-type') || 'donate';
  const price = card.getAttribute('data-price') || '';
  const expiry = card.getAttribute('data-expiry') || '';
  const pickupDate = card.getAttribute('data-pickupdate') || '';
  const pickupLocation = card.getAttribute('data-pickuplocation') || '';

  document.querySelectorAll('.quick-item-card').forEach(el => {
    el.classList.remove('selected');
  });

  card.classList.add('selected');

  document.getElementById('quickItemId').value = itemId;
  document.getElementById('quickQuantity').value = quantity;
  document.getElementById('quickType').value = type;
  document.getElementById('quickPrice').value = price;
  document.getElementById('quickExpiryDate').value = expiry;
  document.getElementById('quickPickupDate').value = pickupDate;
  document.getElementById('quickPickupLocation').value = pickupLocation;

  handleQuickTypeChange();

  const viewItemsHelper = document.getElementById('viewItemsHelper');
  const quickUpdateHelper = document.getElementById('quickUpdateHelper');
  const viewItemsBtn = document.getElementById('viewItemsBtn');
  const quickUpdateBtn = document.getElementById('quickUpdateBtn');
  const panel = document.getElementById('quickUpdatePanel');

  if (viewItemsHelper) viewItemsHelper.style.display = 'none';
  if (quickUpdateHelper) quickUpdateHelper.style.display = 'block';
  if (viewItemsBtn) viewItemsBtn.classList.remove('active');
  if (quickUpdateBtn) quickUpdateBtn.classList.add('active');
  if (panel) panel.style.display = 'block';
}
</script>
function handleQuickTypeChange() {
  const type = document.getElementById('quickType').value;
  const priceInput = document.getElementById('quickPrice');
  if (!priceInput) return;

  if (type === 'donate') {
    priceInput.disabled = true;
    priceInput.value = 0;
  } else {
    priceInput.disabled = false;
  }
}

function saveQuickUpdate() {
  const payload = {
    id: document.getElementById('quickItemId').value,
    quantity: document.getElementById('quickQuantity').value,
    listingType: document.getElementById('quickType').value,
    price: document.getElementById('quickPrice').value,
    expiryDate: document.getElementById('quickExpiryDate').value,
    pickupDate: document.getElementById('quickPickupDate').value,
    pickupLocationId: document.getElementById('quickPickupLocation').value
  };

  fetch('provider-items.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      showQuickToast('Updated successfully');
      setTimeout(() => location.reload(), 800);
    } else {
      showQuickToast(data.message || 'Update failed');
    }
  })
  .catch(() => showQuickToast('Something went wrong'));
}

function resetAddItemModal() {
  const form = document.getElementById('addItemForm');
  if (form) form.reset();

  document.getElementById('formAction').value = 'addItem';
  document.getElementById('editItemId').value = '';
  document.getElementById('existingPhotoUrl').value = '';
  document.getElementById('currentImageWrap').style.display = 'none';
  document.getElementById('currentImagePreview').src = '';
  document.querySelector('#addItemModal h1').textContent = 'Add Item';
  document.querySelector('#addItemForm .add-btn').textContent = 'Add Item';
  document.getElementById('priceInput').disabled = true;
  document.getElementById('priceInput').value = 0;

  const donateRadio = document.querySelector('input[name="itemType"][value="donate"]');
  if (donateRadio) donateRadio.checked = true;
}

function openEditItemModal(btn, event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
  }

  document.getElementById('addItemModal').style.display = 'flex';
  document.getElementById('formAction').value = 'editItem';
  document.getElementById('editItemId').value = btn.dataset.id || '';
  document.getElementById('itemName').value = btn.dataset.name || '';
  document.getElementById('itemDetails').value = btn.dataset.description || '';
  document.getElementById('categoryId').value = btn.dataset.categoryid || '';
  document.getElementById('pickupLocationId').value = btn.dataset.pickuplocation || '';
  document.getElementById('pickupDate').value = btn.dataset.pickupdate || '';
  document.getElementById('existingPhotoUrl').value = btn.dataset.photo || '';
  document.getElementById('priceInput').value = btn.dataset.price || '';

  const itemType = btn.dataset.type || 'donate';
  const donateRadio = document.querySelector('input[name="itemType"][value="donate"]');
  const sellRadio = document.querySelector('input[name="itemType"][value="sell"]');

  if (itemType === 'sell') {
    if (sellRadio) sellRadio.checked = true;
    document.getElementById('priceInput').disabled = false;
  } else {
    if (donateRadio) donateRadio.checked = true;
    document.getElementById('priceInput').disabled = true;
    document.getElementById('priceInput').value = 0;
  }

  if (btn.dataset.photo) {
    document.getElementById('currentImageWrap').style.display = 'block';
    document.getElementById('currentImagePreview').src = btn.dataset.photo;
  } else {
    document.getElementById('currentImageWrap').style.display = 'none';
    document.getElementById('currentImagePreview').src = '';
  }

  document.querySelector('#addItemModal h1').textContent = 'Edit Item';
  document.querySelector('#addItemForm .add-btn').textContent = 'Update Item';
}

function deleteItem(itemId, event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
  }
  deleteTargetItemId = itemId;
  document.getElementById('deleteModal').style.display = 'flex';
}

function closeDeleteModal() {
  deleteTargetItemId = '';
  document.getElementById('deleteModal').style.display = 'none';
}

function confirmDeleteItem() {
  if (!deleteTargetItemId) return;

  const formData = new FormData();
  formData.append('formAction', 'deleteItem');
  formData.append('itemId', deleteTargetItemId);

  fetch('provider-items.php', {
    method: 'POST',
    body: formData
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      closeDeleteModal();
      showQuickToast('Item deleted successfully');
      setTimeout(() => location.reload(), 500);
    } else {
      showQuickToast(data.message || 'Delete failed');
    }
  })
  .catch(() => showQuickToast('Something went wrong'));
}

function renderSearchResults(items, dropdown, closeMenuAfter) {
  let html = '';

  if (!items.length) {
    html = '<div style="padding:14px;text-align:center;color:#8a9ab5;font-size:13px;">No matches found</div>';
  } else {
    html += '<div class="sd-section-title">Products</div>';

    items.forEach(item => {
      const thumb = item.photoUrl
        ? `<div class="sd-icon"><img src="${esc(item.photoUrl)}" alt=""></div>`
        : `<div class="sd-icon">🍱</div>`;

      const isDonate = (item.listingType || '').toLowerCase() === 'donate';
      const priceText = isDonate || !item.price || Number(item.price) === 0 ? 'Free' : `SAR ${esc(item.price)}`;
      const badgeClass = isDonate ? 'sd-badge sd-badge-donate' : 'sd-badge sd-badge-sell';
      const typeText = isDonate ? 'Donation' : 'Selling';

      html += `
        <a class="sd-row" href="provider-item-details.php?id=${esc(item.id)}" ${closeMenuAfter ? 'onclick="closeMobileMenu()"' : ''}>
          ${thumb}
          <div>
            <div class="sd-name">${esc(item.name || '')}</div>
            <div class="sd-meta">
              <div class="sd-price">${priceText}</div>
              <span class="${badgeClass}">${typeText}</span>
            </div>
          </div>
        </a>
      `;
    });
  }

  dropdown.innerHTML = html;
  dropdown.classList.add('visible');
}

function attachSearch(inputId, dropdownId, closeMenuAfter = false) {
  const input = document.getElementById(inputId);
  const dropdown = document.getElementById(dropdownId);
  if (!input || !dropdown) return;

  input.addEventListener('input', function () {
    clearTimeout(searchTimer);
    const q = this.value.trim().toLowerCase();

    if (q.length < 2) {
      dropdown.classList.remove('visible');
      dropdown.innerHTML = '';
      return;
    }

    dropdown.innerHTML = '<div style="padding:14px;text-align:center;color:#8a9ab5;font-size:13px;">Searching...</div>';
    dropdown.classList.add('visible');

    searchTimer = setTimeout(() => {
      const results = itemSearchData.filter(item =>
        (item.name || '').toLowerCase().includes(q)
      );
      renderSearchResults(results, dropdown, closeMenuAfter);
    }, 180);
  });
}

attachSearch('searchInput', 'searchDropdown', false);
attachSearch('mobileSearchInput', 'mobileSearchDropdown', true);

document.addEventListener('click', function (e) {
  const searchWrap = document.getElementById('searchWrap');
  const searchDropdown = document.getElementById('searchDropdown');
  const mobileSearch = document.querySelector('.mobile-search');
  const mobileSearchDropdown = document.getElementById('mobileSearchDropdown');

  if (searchWrap && searchDropdown && !searchWrap.contains(e.target)) {
    searchDropdown.classList.remove('visible');
  }

  if (mobileSearch && mobileSearchDropdown && !mobileSearch.contains(e.target)) {
    mobileSearchDropdown.classList.remove('visible');
  }
});

document.getElementById('addItemModal').addEventListener('click', function (e) {
  if (e.target === this) this.style.display = 'none';
});

document.getElementById('deleteModal').addEventListener('click', function (e) {
  if (e.target === this) closeDeleteModal();
});

window.onload = function () {
  handleQuickTypeChange();
  resetAddItemModal();
};
</script>
</body>
</html>
